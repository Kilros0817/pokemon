/**
 * Pokedex Table Component - Displays Pokémon in a sortable, filterable table
 * Implements client-side pagination, filtering, and sorting with Angular Signals
 */
import { Component, OnInit, DestroyRef, inject, signal, computed, ChangeDetectionStrategy, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PokemonStore, Pokemon } from '../../../state/pokemon/pokemon.store';
import { PokemonDetailComponent } from '../pokemon-detail/pokemon-detail.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { LoggerService } from '../../../core/services/logger.service';
import { ScrollingModule, CdkVirtualScrollViewport } from '@angular/cdk/scrolling';

@Component({
  selector: 'app-pokedex-table',
  standalone: true,
  imports: [CommonModule, FormsModule, ScrollingModule, PokemonDetailComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './pokedex-table.component.html',
  styleUrls: ['./pokedex-table.component.scss']
})
export class PokedexTablePage implements OnInit {
  private pokemonStore = inject(PokemonStore);
  private destroyRef = inject(DestroyRef);
  private logger = inject(LoggerService);
  
  // UI state signals
  readonly loading = signal<boolean>(false);
  readonly searchTerm = signal<string>('');
  readonly selectedType = signal<string>('');
  readonly minStats = signal<number>(0);
  readonly maxStats = signal<number>(1000);
  readonly sortBy = signal<string>('id');
  readonly sortDir = signal<'asc' | 'desc'>('asc');
  readonly batchSize = signal<number>(20);
  readonly totalCount = signal<number>(0);
  readonly loadedOffset = signal<number>(0);
  readonly isLoadingMore = signal<boolean>(false);
  
  // Data signals
  readonly allPokemon = signal<Pokemon[]>([]);
  readonly selectedPokemon = signal<Pokemon | null>(null);
  
  /**
   * Computed signal for available Pokémon types
   * Extracts unique types from all Pokémon
   */
  availableTypes = computed(() => {
    const types = new Set<string>();
    this.allPokemon().forEach(p => p.types.forEach(t => types.add(t)));
    return Array.from(types).sort();
  });
  
  /**
   * Computed signal for filtered and sorted Pokémon
   * Applies search, type filter, stats range, and sorting
   */
  filteredPokemon = computed(() => {
    let results = [...this.allPokemon()];
    const search = this.searchTerm().toLowerCase();
    const type = this.selectedType();
    
    // Apply text search filter (minimum 2 characters)
    if (search.length >= 2) {
      results = results.filter(p => p.name.toLowerCase().includes(search));
    }
    
    // Apply type filter
    if (type) {
      results = results.filter(p => p.types.includes(type));
    }
    
    // Apply total stats range filter
    results = results.filter(p => {
      const total = this.calculateTotalStats(p);
      return total >= this.minStats() && total <= this.maxStats();
    });
    
    // Apply sorting
    results.sort((a, b) => {
      const sortBy = this.sortBy();
      const sortDir = this.sortDir();
      
      let aVal: any, bVal: any;
      
      switch (sortBy) {
        case 'id':
          aVal = a.id;
          bVal = b.id;
          break;
        case 'name':
          aVal = a.name.toLowerCase();
          bVal = b.name.toLowerCase();
          break;
        case 'total':
          aVal = this.calculateTotalStats(a);
          bVal = this.calculateTotalStats(b);
          break;
        case 'hp':
        case 'attack':
        case 'defense':
        case 'specialAttack':
        case 'specialDefense':
        case 'speed':
          aVal = a.stats[sortBy as keyof typeof a.stats];
          bVal = b.stats[sortBy as keyof typeof b.stats];
          break;
        default:
          aVal = a.id;
          bVal = b.id;
      }
      
      if (sortDir === 'asc') {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });
    
    return results;
  });
  
  /**
   * True while more Pokémon can be requested from the API.
   */
  hasMorePokemon = computed(() => {
    const total = this.totalCount();
    return total === 0 || this.loadedOffset() < total;
  });

  /**
   * Initializes component by loading Pokémon data
   */
  @ViewChild(CdkVirtualScrollViewport)
  private viewport?: CdkVirtualScrollViewport;

  /**
   * Initializes component by loading the first virtual-scroll batch.
   */
  ngOnInit(): void {
    this.loadNextBatch(true);
  }

  /**
   * Loads Pokémon in batches of 20. The first load replaces the list;
   * later loads append to the existing virtual scroll data source.
   */
  loadNextBatch(initialLoad = false): void {
    if (this.isLoadingMore() || (!initialLoad && !this.hasMorePokemon())) {
      return;
    }

    this.loading.set(initialLoad);
    this.isLoadingMore.set(true);

    const limit = this.batchSize();
    const offset = initialLoad ? 0 : this.loadedOffset();

    this.pokemonStore.fetchPokemonList(limit, offset)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (pokemon) => {
          this.allPokemon.update(current => initialLoad ? pokemon : [...current, ...pokemon]);
          this.loadedOffset.set(offset + pokemon.length);
          this.totalCount.set(this.pokemonStore.state().totalCount);
          this.loading.set(false);
          this.isLoadingMore.set(false);
        },
        error: (error) => {
          this.logger.error('Error loading Pokémon:', error);
          this.loading.set(false);
          this.isLoadingMore.set(false);
        }
      });
  }

  /**
   * Triggered by CDK virtual scroll. When the rendered range gets close
   * to the currently loaded data, request the next API batch.
   */
  onScrolledIndexChange(): void {
    const viewport = this.viewport;
    if (!viewport || this.isLoadingMore() || !this.hasMorePokemon()) {
      return;
    }

    const renderedRange = viewport.getRenderedRange();
    const loadedLength = this.filteredPokemon().length;
    const preloadThreshold = 5;

    if (renderedRange.end >= loadedLength - preloadThreshold) {
      this.loadNextBatch();
    }
  }
  
  /**
   * Calculates total base stats for a Pokémon
   *
   * @param pokemon - Pokémon entity
   * @returns Sum of all base stats
   */
  calculateTotalStats(pokemon: Pokemon): number {
    return pokemon.stats.hp + pokemon.stats.attack + pokemon.stats.defense +
           pokemon.stats.specialAttack + pokemon.stats.specialDefense + pokemon.stats.speed;
  }
  
  /**
   * Handles search term change and resets to first page
   */
  onSearchChange(): void {
    this.scrollToTop();
  }
  
  /**
   * Handles type filter change and resets to first page
   */
  onTypeChange(): void {
    this.scrollToTop();
  }
  
  /**
   * Handles stats range change and resets to first page
   */
  onStatsChange(): void {
    this.scrollToTop();
  }
  
  private scrollToTop(): void {
    this.viewport?.scrollToIndex(0);
  }
  
  /**
   * Sorts table by column
   * Toggles direction if same column, sets to ascending if new column
   *
   * @param column - Column name to sort by
   */
  sort(column: string): void {
    if (this.sortBy() === column) {
      this.sortDir.update(dir => dir === 'asc' ? 'desc' : 'asc');
    } else {
      this.sortBy.set(column);
      this.sortDir.set('asc');
    }
  }
  


  trackPokemon(index: number, pokemon: Pokemon): number {
    return pokemon.id;
  }

  /**
   * Handles Pokémon row click to show detail panel
   *
   * @param pokemon - Selected Pokémon
   */
  onPokemonClick(pokemon: Pokemon): void {
    this.selectedPokemon.set(pokemon);
  }
  
  /**
   * Closes Pokémon detail panel
   */
  closeDetailPanel(): void {
    this.selectedPokemon.set(null);
  }
  
  /**
   * Handles image loading errors by setting fallback sprite
   *
   * @param event - Image error event
   */
  onImageError(event: Event): void {
    const img = event.target as HTMLImageElement;
    img.src = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/0.png';
  }
}